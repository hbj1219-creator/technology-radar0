# 기술 레이더 코드

산업·기업별 기술 소식 해설 및 동향 분석 플랫폼

## 폴더 선택

- **vercel/**: Vercel에 배포할 Next.js 버전. 발표용으로 먼저 사용할 폴더입니다.
- **original/**: 기존 사이트 소스. Cloudflare Workers·D1 저장소와 ChatGPT Sites 설정을 사용하는 원본입니다. Vercel에 그대로 배포하면 작동하지 않습니다.

원본 기준: 2026-10-11, 커밋 59314d61fdf6a4b17eaeaef56d1aadf3c0c6c3f4.
원본의 계정 설정·인증 토큰·개인 환경 파일·데이터베이스 전체 덤프는 포함하지 않았습니다.

## Vercel로 링크 만들기

1. 압축을 풀고 `vercel` 폴더를 선택합니다.
2. GitHub에 새 저장소를 만들고 **vercel 폴더 안의 파일과 폴더**를 올립니다. 저장소 첫 화면에 `package.json`, `app`, `public`이 보여야 합니다.
3. [Vercel](https://vercel.com/new)에 GitHub 계정으로 연결한 뒤 그 저장소를 Import합니다.
4. Framework Preset은 **Next.js**, Node.js는 **24.x**, Root Directory는 기본값으로 둡니다. 별도 환경 변수는 필요 없습니다. Build Command는 `pnpm build`입니다.
5. 프로젝트 이름을 정하고 **Deploy**를 누릅니다. 배포 완료 화면에 나온 `…vercel.app` 주소를 사용합니다. 주소는 실제 배포 후 확인해야 하며, 원하는 이름이 사용 중이면 다른 이름이 필요할 수 있습니다.

두 폴더를 통째로 GitHub에 올렸다면 Vercel의 Root Directory를 **vercel**로 지정하세요.

## 지금 옮겨지는 범위

화면·해설·산업 필터·관심 기업·기업별 동향·달력·소식이 있는 날짜만 선택하는 리포트를 포함합니다. 관심 기업, 관심 기술, 저장한 자료는 로그인 없이 현재 브라우저에 저장됩니다. 다른 기기와 동기화되지 않으며 기존 사이트의 선택 정보가 새 주소로 자동 이전되지는 않습니다.

Vercel 버전에는 정리된 자료 31건, 기업 동향 60건과 검토 보도 36건의 공개 메타데이터를 넣었습니다. **기존 사이트의 수만 건 수집 기사 전체와 자동 갱신 기능까지 이전한 버전은 아닙니다.** 배포에 포함된 소식은 고정 자료입니다. 화면에도 자료 기준일을 표시했습니다.

논문·외부 보도 검색 및 보도량 집계 코드는 들어 있으며, 해당 외부 서비스의 응답·제한에 따라 결과가 달라집니다. 뉴스레터·유료 구독·댓글·커뮤니티 기능은 아직 구현하지 않았습니다.

완전한 운영 이전에는 데이터베이스와 수집 작업, 계정 로그인·기기 간 동기화를 따로 연결해야 합니다. 이번 파일을 내려받는 것만으로 Vercel 배포나 주소 변경이 이루어지지는 않습니다.

## 코드 위치

- `vercel/app/radar.tsx`: 메인 화면, 메뉴, 브라우저 관심·저장 기능
- `vercel/app/daily-report.tsx`: 핵심 리포트
- `vercel/app/industry-overview.tsx`: 기업별 동향과 내 관심 동향
- `vercel/app/industry-calendar.tsx`: 산업별 달력과 회사 이름 툴팁
- `vercel/lib/daily-report.ts`: 소식 선택과 중복 묶기
- `vercel/lib/importance.ts`: 중요도 평가
- `vercel/data/short-explanations.json`: 짧은 용어·적용·효과 해설
- `vercel/data/site-snapshot.json`, `news-snapshot.json`: 배포에 포함된 공개 소식

자료를 수정한 뒤 GitHub에 다시 올리면 연결된 Vercel 프로젝트에서 재배포할 수 있습니다. 소식 날짜와 원문 근거는 함께 유지하세요.

공식 안내: https://vercel.com/docs/git
