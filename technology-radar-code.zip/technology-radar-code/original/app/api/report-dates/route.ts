import {database} from '@/lib/radar-store';
import {industries,type RecordItem} from '@/lib/radar-data';
import type {IndustryUpdate} from '@/lib/industry-update';
import type {SearchItem} from '@/lib/search-topics';
import {selectIndustryNews,type IndustryNewsItem} from '@/lib/industry-news';
import {industryNewsQuery} from '@/lib/industry-news-query';
import {dailyReportDates} from '@/lib/daily-report';
import {applyEditorialCorrection} from '@/lib/editorial-updates';
import {applyEventAssessment} from '@/lib/event-assessments';
import {evaluateImportance} from '@/lib/importance';
import reviews from '@/data/reported-briefings.json';

const cache=new Map<string,{expires:number;dates:string[]}>();
export async function GET(request:Request){
 const industry=new URL(request.url).searchParams.get('industry')||'all';
 if(!['all',...industries].includes(industry))return Response.json({error:'산업을 확인해 주세요.'},{status:400});
 const {clause,args,today}=industryNewsQuery(industry,'all','since'),key=industry+'|'+today,cached=cache.get(key);
 if(cached&&cached.expires>Date.now())return Response.json({dates:cached.dates},{headers:{'Cache-Control':'no-store'}});
 try{
  const db=database(),[updateRows,recordRows]=await Promise.all([
   db.prepare('SELECT body FROM industry_updates ORDER BY published DESC,id').all<{body:string}>(),
   db.prepare('SELECT body FROM records WHERE published>=? AND published<=? ORDER BY published DESC').bind('2026-07-01',today).all<{body:string}>()
  ]);
  const assess=(body:string)=>{const item=applyEventAssessment(applyEditorialCorrection(JSON.parse(body)));return {...item,importance:evaluateImportance(item)};};
  const updates=updateRows.results.map(r=>assess(r.body)) as IndustryUpdate[],records=recordRows.results.map(r=>assess(r.body)) as RecordItem[],reports:IndustryNewsItem[]=[];
  // English headlines without a reviewed explanation cannot become a daily topic.
  // Keep all Korean candidates and evidence-bound reviewed articles, then apply the actual report logic.
  const ids=JSON.stringify([...new Set(reviews.flatMap(r=>r.articles.map(a=>a.id)))]),titles=JSON.stringify([...new Set(reviews.flatMap(r=>r.articles.map(a=>a.title.replace(/[\\%_]/g,'\\$&')+'%')))]);
  let anchor:{published:string;id:string}|undefined;
  while(true){
   const rows=await db.prepare('SELECT body,published,id FROM news_articles WHERE '+clause+" AND (title GLOB '*[가-힣]*' OR id IN (SELECT value FROM json_each(?)) OR EXISTS (SELECT 1 FROM json_each(?) review_title WHERE news_articles.title LIKE review_title.value ESCAPE '\\'))"+(anchor?' AND (published<? OR (published=? AND id>?))':'')+' ORDER BY published DESC,id LIMIT 1000').bind(...args,ids,titles,...(anchor?[anchor.published,anchor.published,anchor.id]:[])).all<{body:string;published:string;id:string}>();
   for(const row of rows.results){const item=JSON.parse(row.body) as SearchItem;reports.push(...selectIndustryNews({...item,importance:evaluateImportance(item)},industry));}
   if(rows.results.length<1000)break;
   anchor=rows.results.at(-1)!;
  }
  const dates=dailyReportDates(updates,records,today,reports,industry);
  if(cache.size>=16)cache.delete(cache.keys().next().value!);
  cache.set(key,{expires:Date.now()+120000,dates});
  return Response.json({dates},{headers:{'Cache-Control':'no-store'}});
 }catch(e){console.error('Report dates failed',e instanceof Error?e.message:'unknown');return Response.json({error:'소식이 있는 날짜를 불러오지 못했습니다.'},{status:503});}
}
