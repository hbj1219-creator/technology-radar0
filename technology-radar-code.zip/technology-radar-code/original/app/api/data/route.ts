import {env} from "cloudflare:workers";
import {isRadarUpdater} from "@/lib/radar-updater-auth";
import {readData} from "@/lib/radar-store";
export async function GET(request:Request){try{return Response.json(await readData(request.headers.get("oai-authenticated-user-id"),request.headers.has("x-radar-updater-token")&&await isRadarUpdater(request,env.RADAR_UPDATER_TOKEN)),{headers:{"Cache-Control":"no-store"}});}catch(e){console.error(e);return Response.json({error:"자료를 불러오지 못했습니다. 잠시 후 다시 시도해 주세요."},{status:503});}}
