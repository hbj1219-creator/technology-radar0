import {env} from 'cloudflare:workers';
import {isRadarUpdater} from '@/lib/radar-updater-auth';
import {industries} from '@/lib/radar-data';
import {collectNewsBatch,collectionQueries} from '@/lib/news-collection';
import {database} from '@/lib/radar-store';
import {z} from 'zod';
const input=z.object({industry:z.string().refine(v=>industries.includes(v)),mode:z.enum(['recent','backfill'])});
export async function GET(){
 try{const db=database(),counts=await db.prepare('SELECT ni.industry,COUNT(*) AS count FROM news_industries ni GROUP BY ni.industry').all(),total=await db.prepare('SELECT COUNT(*) AS count FROM news_articles').first(),progress=await db.prepare('SELECT industry,mode,position,total,updated,failures,note,(SELECT COUNT(*) FROM news_collection_retries r WHERE r.scope=s.scope) AS pending FROM news_collection_state s ORDER BY updated DESC LIMIT 32').all();return Response.json({industries,queries:Object.fromEntries(industries.map(i=>[i,collectionQueries(i).length])),counts:counts.results,total,progress:progress.results},{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({error:'수집 상태를 읽지 못했습니다.'},{status:503});}
}
export async function POST(request:Request){
 if(!await isRadarUpdater(request,env.RADAR_UPDATER_TOKEN))return Response.json({error:'기사 수집 권한이 없습니다.'},{status:403});
 const origin=request.headers.get('origin');if(origin&&new URL(origin).host!==new URL(request.url).host)return Response.json({error:'허용되지 않은 요청입니다.'},{status:403});
 try{const body=input.safeParse(await request.json());if(!body.success)return Response.json({error:'수집 조건을 확인해 주세요.'},{status:400});return Response.json(await collectNewsBatch(body.data.industry,body.data.mode),{headers:{'Cache-Control':'no-store'}});}catch(e){console.error('News collection failed:',e);return Response.json({error:'기사 수집에 실패했습니다. 다음 실행에서 이어서 수집합니다.'},{status:503});}
}
