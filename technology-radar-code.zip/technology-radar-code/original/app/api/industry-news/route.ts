import {database} from '@/lib/radar-store';
import {industries} from '@/lib/radar-data';
import {selectIndustryNews} from '@/lib/industry-news';
import {validPeriod} from '@/lib/search-period';
import {industryNewsQuery} from '@/lib/industry-news-query';
import type {SearchItem} from '@/lib/search-topics';
import {evaluateImportance,isVisibleImportance} from '@/lib/importance';

const PAGE_SIZE=2000;
const counts=new Map<string,{total:number;updated:number}>();
async function candidateCount(key:string,read:()=>Promise<{total:number}|null>){
 const cached=counts.get(key);if(cached&&Date.now()-cached.updated<120000)return cached.total;
 const total=(await read())?.total||0;
 if(counts.size>=32)counts.delete(counts.keys().next().value!);
 counts.set(key,{total,updated:Date.now()});return total;
}
export async function GET(request:Request){
 const p=new URL(request.url).searchParams,industry=p.get('industry')||'반도체',company=p.get('company')||'all',period=p.get('period')||'since',cursor=p.get('cursor');
 if(![...industries,'all'].includes(industry)||!validPeriod(period)||(cursor?.length||0)>256)return Response.json({error:'동향 조건을 확인해 주세요.'},{status:400});
 const {companies,from,today,clause,args}=industryNewsQuery(industry,company,period);
 if(company!=='all'&&!companies.includes(company))return Response.json({error:'동향 조건을 확인해 주세요.'},{status:400});
 let anchor:{published:string;id:string}|null=null;
 if(cursor){try{anchor=JSON.parse(cursor);if(!anchor||!/^news:[a-f0-9]{64}$/.test(anchor.id)||!/^\d{4}-\d{2}-\d{2}$/.test(anchor.published))throw Error();}catch{return Response.json({error:'기사 페이지 조건을 확인해 주세요.'},{status:400});}}
 const db=database();
 try{
  const [count,rows]=await Promise.all([
   candidateCount(JSON.stringify([industry,company,from,today]),()=>db.prepare('SELECT COUNT(*) AS total FROM news_articles WHERE '+clause).bind(...args).first<{total:number}>()),
   db.prepare('SELECT body FROM news_articles WHERE '+clause+(anchor?' AND (published<? OR (published=? AND id>?))':'')+' ORDER BY published DESC,id LIMIT '+(PAGE_SIZE+1)).bind(...args,...(anchor?[anchor.published,anchor.published,anchor.id]:[])).all<{body:string}>()
  ]);
  const raw=rows.results.slice(0,PAGE_SIZE).map(r=>{const item=JSON.parse(r.body) as SearchItem;return {...item,importance:evaluateImportance(item)};}),last=raw.at(-1);
  return Response.json({items:raw.filter(isVisibleImportance).flatMap(item=>selectIndustryNews(item,industry,company)),scanned:raw.length,available:count,nextCursor:rows.results.length>PAGE_SIZE&&last?JSON.stringify({published:last.published,id:last.id}):null},{headers:{'Cache-Control':'no-store'}});
 }catch(e){console.error('Industry news failed',e instanceof Error?e.message:'unknown');return Response.json({error:'수집 보도를 불러오지 못했습니다. 다시 시도해 주세요.'},{status:503});}
}
