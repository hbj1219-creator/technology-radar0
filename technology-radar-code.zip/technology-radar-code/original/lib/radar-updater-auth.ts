// The updater key lives only in hosted runtime secrets, never in the browser or source.
export async function isRadarUpdater(request:Request,expected:string|undefined):Promise<boolean>{
 const token=request.headers.get("x-radar-updater-token");
 if(!expected||!token||token.length<32||token.length>4096)return false;
 const bytes=new TextEncoder();
 const [a,b]=await Promise.all([crypto.subtle.digest("SHA-256",bytes.encode(token)),crypto.subtle.digest("SHA-256",bytes.encode(expected))]);
 const x=new Uint8Array(a),y=new Uint8Array(b);let diff=0;
 for(let i=0;i<x.length;i++)diff|=x[i]^y[i];
 return diff===0;
}
