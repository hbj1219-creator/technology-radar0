import {companyWatchlist} from './industry-update';
import {companyTerms} from './industry-news';
import {rangeFor} from './search-period';

/** Keep the report date index and the article list on the same candidate query. */
export function industryNewsQuery(industry:string,company:string,period:string){
 const companies=[...new Set((industry==='all'?Object.values(companyWatchlist).flat():companyWatchlist[industry]||[]).map(c=>c.name))];
 const {from,today}=rangeFor(period),terms=[...new Set((company==='all'?companies:[company]).flatMap(companyTerms))];
 const patterns=terms.map(term=>'%'+term.replace(/[\\%_]/g,'\\$&')+'%');
 const clause="published>=? AND published<=? AND "+(patterns.length<=90?'('+patterns.map(()=>"title LIKE ? ESCAPE '\\'").join(' OR ')+')':"EXISTS (SELECT 1 FROM json_each(?) term WHERE news_articles.title LIKE term.value ESCAPE '\\')");
 const args=[from,today,...(patterns.length<=90?patterns:[JSON.stringify(patterns)])];
 return {companies,from,today,clause,args};
}
