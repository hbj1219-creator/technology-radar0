import {applyEventAssessment} from './event-assessments';
import type {IndustryUpdate} from './industry-update';
import {reportedArticleIds,reportedBriefing} from './reported-briefings';
import {evaluateImportance} from './importance';
import {shortExplanation} from './short-explanation';
import type {SearchItem} from './search-topics';

export async function refreshStoredAssessments(db:D1Database){
 const rows=await db.prepare('SELECT id,body FROM industry_updates').all<{id:string;body:string}>();
 const changes=rows.results.flatMap(row=>{
  const item=JSON.parse(row.body) as IndustryUpdate,assessed=applyEventAssessment(item);
  return JSON.stringify(item.assessment)===JSON.stringify(assessed.assessment)?[]:[{id:row.id,before:row.body,after:JSON.stringify(assessed)}];
 });
 let updated=0;
 for(let offset=0;offset<changes.length;offset+=100){
  const result=await db.prepare("WITH changes AS (SELECT json_extract(value,'$.id') AS id,json_extract(value,'$.before') AS old_body,json_extract(value,'$.after') AS new_body FROM json_each(?)) UPDATE industry_updates SET body=(SELECT new_body FROM changes WHERE changes.id=industry_updates.id) WHERE id IN (SELECT id FROM changes) AND body=(SELECT old_body FROM changes WHERE changes.id=industry_updates.id)").bind(JSON.stringify(changes.slice(offset,offset+100))).run();
  updated+=result.meta.changes||0;
 }
 const media=await db.prepare('SELECT id,body FROM news_articles WHERE id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(reportedArticleIds)).all<{id:string;body:string}>();
 const reviewedChanges=media.results.flatMap(row=>{
  const item=JSON.parse(row.body) as SearchItem,review=reportedBriefing(item);if(!review)return [];
  const next={...item,importance:evaluateImportance(item),assessment:{label:review.label,reason:review.reason,sourceUrls:[item.url],reviewed:true,basis:'editorial'},briefExplanation:shortExplanation(item),eventKey:review.key};
  const after=JSON.stringify(next);return after===row.body?[]:[{id:row.id,before:row.body,after}];
 });
 let reportedUpdated=0;
 for(let offset=0;offset<reviewedChanges.length;offset+=100){
  const result=await db.prepare("WITH changes AS (SELECT json_extract(value,'$.id') AS id,json_extract(value,'$.before') AS old_body,json_extract(value,'$.after') AS new_body FROM json_each(?)) UPDATE news_articles SET body=(SELECT new_body FROM changes WHERE changes.id=news_articles.id) WHERE id IN (SELECT id FROM changes) AND body=(SELECT old_body FROM changes WHERE changes.id=news_articles.id)").bind(JSON.stringify(reviewedChanges.slice(offset,offset+100))).run();
  reportedUpdated+=result.meta.changes||0;
 }
 return {updated,reportedUpdated};
}
