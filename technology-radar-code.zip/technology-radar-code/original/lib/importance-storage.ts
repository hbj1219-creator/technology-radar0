import {evaluateImportance,IMPORTANCE_REVISION,type ImportanceInput} from './importance';
import {applyEditorialCorrection} from './editorial-updates';

const TABLES=['records','industry_updates','news_articles'] as const;
const FINANCE_PATTERNS=['%차익실현%','%하락마감%','%상승마감%','%상한가%','%하한가%','%급등주%','%급락주%','%시가총액%','%시총%','%주식투자%','%주식시장%','%증권사%','%증권시장%','%투자전략%','%투자추천%','%매매전략%','%결산분석%','%결산발표%','%결산결과%'];
const needsReview="(COALESCE(json_extract(body,'$.importance.revision'),0)<>? OR (COALESCE(json_extract(body,'$.importance.stars'),0)>0 AND EXISTS(SELECT 1 FROM json_each(?) pattern WHERE replace(replace(replace(replace(json_extract(body,'$.title'),' ',''),char(9),''),char(10),''),char(13),'') LIKE pattern.value)))";
let active:Promise<ReturnType<typeof progress>>|undefined;
function progress(updated:number,remaining:number){return {revision:IMPORTANCE_REVISION,updated,remaining};}
/** Bounded, repeatable data migration. Only ratings/corrected copy change; concurrent ingestion wins. */
export function refreshStoredImportance(db:D1Database){
 if(active)return active;
 active=(async()=>{
  let updated=0,remaining=0;
  for(const table of TABLES){
   const rows=await db.prepare(`SELECT id,body FROM ${table} WHERE ${needsReview} ORDER BY id LIMIT 4000`).bind(IMPORTANCE_REVISION,JSON.stringify(FINANCE_PATTERNS)).all<{id:string;body:string}>();
   for(let start=0;start<rows.results.length;start+=100){
    const changes=rows.results.slice(start,start+100).map(row=>{
     const item=applyEditorialCorrection(JSON.parse(row.body) as ImportanceInput&{id:string});
     return {id:row.id,before:row.body,after:JSON.stringify({...item,importance:evaluateImportance(item)})};
    });
    // One bound JSON parameter, indexed row selection, and compare-and-swap preserve concurrent collection.
    const statement=db.prepare(`WITH changes AS (SELECT json_extract(value,'$.id') AS id,json_extract(value,'$.before') AS old_body,json_extract(value,'$.after') AS new_body FROM json_each(?)) UPDATE ${table} SET body=(SELECT new_body FROM changes WHERE changes.id=${table}.id) WHERE id IN (SELECT id FROM changes) AND body=(SELECT old_body FROM changes WHERE changes.id=${table}.id)`).bind(JSON.stringify(changes));
    const result=await db.batch([statement]);updated+=result.reduce((n,r)=>n+(r.meta.changes||0),0);
   }
   const count=await db.prepare(`SELECT COUNT(*) AS count FROM ${table} WHERE ${needsReview}`).bind(IMPORTANCE_REVISION,JSON.stringify(FINANCE_PATTERNS)).first<{count:number}>();
   remaining+=count?.count||0;
  }
  return progress(updated,remaining);
 })().finally(()=>{active=undefined;});
 return active;
}
