import {evaluateImportance} from './importance';
import {database} from './radar-store';
import {industries,technologies} from './radar-data';
import {companyWatchlist} from './industry-update';
import {searchAliases,topicQueries,type SearchItem,type SearchResult} from './search-topics';
import {fetchNewsWindow} from './external-search';
import {DATA_START,koreaDay,rangeFor} from './search-period';

const nextDay=(day:string,n=1)=>new Date(Date.parse(day+'T00:00:00Z')+n*86400000).toISOString().slice(0,10);
export function collectionQueries(industry:string){
 const broad=searchAliases(industry).news;
 const companies=(companyWatchlist[industry]||[]).map(c=>c.name);
 const leaves=technologies.filter(t=>t.industries.includes(industry)).flatMap(t=>[t.name,topicQueries[t.id]||t.name]);
 return [...new Set([...broad,...companies,...leaves])];
}
async function digest(text:string){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))].map(n=>n.toString(16).padStart(2,'0')).join('');}
type State={scope:string;position:number;total:number;failures:number;note:string};
export async function collectNewsBatch(industry:string,mode:'recent'|'backfill'){
 const db=database(),today=koreaDay(),until=nextDay(today),queries=collectionQueries(industry);
 const windows:{from:string;until:string}[]=[];
 if(mode==='recent')windows.push({from:nextDay(today,-7)<DATA_START?DATA_START:nextDay(today,-7),until});
 else{let month=DATA_START;while(month<=today){const d=new Date(month+'T00:00:00Z');d.setUTCMonth(d.getUTCMonth()+1);const end=d.toISOString().slice(0,10);windows.push({from:month,until:end<until?end:until});month=end;}}
 const signature=(await digest('query-major-v2\n'+queries.join('\n'))).slice(0,12);
 const scope=`${mode}:${industry}:${mode==='recent'?today:today.slice(0,7)}:${signature}`;
 // Cover every requested month for a query before moving to the next query.
 const jobs=queries.flatMap(query=>windows.map(w=>({...w,query})));
 const now=Date.now(),stamp=new Date(now).toISOString();
 await db.prepare('INSERT INTO news_collection_state(scope,industry,mode,position,total,updated,lock_until,failures,note) VALUES(?,?,?,0,?,?,0,0,?) ON CONFLICT(scope) DO NOTHING').bind(scope,industry,mode,jobs.length,stamp,'수집 대기').run();
 const claim=await db.prepare('UPDATE news_collection_state SET lock_until=? WHERE scope=? AND lock_until<? AND (position<total OR EXISTS(SELECT 1 FROM news_collection_retries r WHERE r.scope=news_collection_state.scope))').bind(now+120000,scope,now).run();
 const state=await db.prepare('SELECT scope,position,total,failures,note FROM news_collection_state WHERE scope=?').bind(scope).first<State>();
 if(!state)throw Error('수집 진행 상태를 읽지 못했습니다.');
 const pendingBefore=await db.prepare('SELECT COUNT(*) AS count FROM news_collection_retries WHERE scope=?').bind(scope).first<{count:number}>();
 if(!claim.meta.changes){const done=state.position>=state.total&&!pendingBefore?.count;return {industry,mode,done,busy:!done,position:state.position,total:state.total,pending:pendingBefore?.count||0,added:0,found:0,failed:0};}
 // Advance through fresh jobs while keeping each failed window for an explicit retry.
 // One unavailable query must not prevent later companies from being checked.
 const retrying=state.position>=jobs.length;
 const indices=retrying?(await db.prepare('SELECT job_index FROM news_collection_retries WHERE scope=? ORDER BY updated,job_index LIMIT 3').bind(scope).all<{job_index:number}>()).results.map(r=>r.job_index):Array.from({length:Math.min(3,jobs.length-state.position)},(_,i)=>state.position+i);
 const batch=indices.map(index=>jobs[index]);
 try{
  const fetched=await Promise.allSettled(batch.map(j=>fetchNewsWindow(j.query,j.from,j.until)));
  const candidates=fetched.flatMap(r=>r.status==='fulfilled'?r.value.items:[]),distinct=[...new Map(candidates.map(i=>[i.title.toLowerCase().replace(/\s+/g,' ').trim()+'|'+i.source+'|'+i.published,i])).values()];
  let added=0;
  const articles=await Promise.all(distinct.map(async item=>({item,id:'news:'+await digest(item.title.toLowerCase().replace(/\s+/g,' ').trim()+'|'+item.source+'|'+item.published)})));
  for(let start=0;start<articles.length;start+=35){
   const slice=articles.slice(start,start+35),statements=slice.flatMap(({item,id})=>[
    db.prepare('INSERT INTO news_articles(id,title,source,published,body,collected) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING').bind(id,item.title,item.source,item.published,JSON.stringify({...item,id,importance:evaluateImportance({...item,id})}),stamp),
    db.prepare('INSERT INTO news_industries(article_id,industry) VALUES(?,?) ON CONFLICT(article_id,industry) DO NOTHING').bind(id,industry)
   ]);
   const saved=await db.batch(statements);added+=saved.filter((_,i)=>i%2===0).reduce((sum,r)=>sum+(r.meta.changes||0),0);
  }
  const retryStatements=fetched.map((result,i)=>result.status==='rejected'||result.value.primaryFailed
   ?db.prepare('INSERT INTO news_collection_retries(scope,job_index,updated,attempts) VALUES(?,?,?,1) ON CONFLICT(scope,job_index) DO UPDATE SET updated=excluded.updated,attempts=attempts+1').bind(scope,indices[i],stamp)
   :db.prepare('DELETE FROM news_collection_retries WHERE scope=? AND job_index=?').bind(scope,indices[i]));
  const failed=fetched.reduce((sum,r)=>sum+(r.status==='rejected'?1:r.value.failed),0),position=retrying?state.position:state.position+batch.length;
  // Save the retry queue and scan cursor atomically after article writes succeed.
  await db.batch([...retryStatements,db.prepare('UPDATE news_collection_state SET position=?,updated=?,lock_until=0,failures=failures+?,note=? WHERE scope=?').bind(position,stamp,failed,`${distinct.length}건 확인 · 신규 ${added}건 · 출처 실패 ${failed}건 · 실패 작업 별도 재시도`,scope)]);
  const pending=await db.prepare('SELECT COUNT(*) AS count FROM news_collection_retries WHERE scope=?').bind(scope).first<{count:number}>();
  return {industry,mode,done:position>=jobs.length&&!pending?.count,busy:false,retry:retrying&&!!pending?.count,position,total:jobs.length,pending:pending?.count||0,retrying,added,found:distinct.length,failed,queries:batch.map(j=>j.query)};
 }catch(e){await db.prepare('UPDATE news_collection_state SET lock_until=0,updated=?,failures=failures+1,note=? WHERE scope=?').bind(stamp,'수집 실패 · 다음 실행에서 재시도',scope).run();throw e;}
}

export async function readNewsCorpus(q:string,page:number,period:string,cursor='*'):Promise<SearchResult>{
 const db=database(),{from,today}=rangeFor(period),industry=industries.find(i=>i.replace(/[·\s]/g,'').toLowerCase()===q.replace(/[·\s]/g,'').toLowerCase());
 const aliases=searchAliases(q),terms=[...new Set([q,aliases.q])];
 const scopeClause=industry?' AND EXISTS(SELECT 1 FROM news_industries ni WHERE ni.article_id=a.id AND ni.industry=?)':q==='전체 산업'?'':` AND (${terms.map(()=>"(a.title LIKE ? OR a.body LIKE ?)").join(' OR ')})`;
 const clause=scopeClause+" AND COALESCE(json_extract(a.body,'$.importance.stars'),0)>=1";
 const args:unknown[]=[from,today,...(industry?[industry]:q==='전체 산업'?[]:terms.flatMap(t=>['%'+t+'%','%'+t+'%']))];
 const count=await db.prepare('SELECT COUNT(*) AS total FROM news_articles a WHERE a.published>=? AND a.published<=?'+clause).bind(...args).first<{total:number}>();
 let anchor:{published:string;id:string}|null=null;
 if(cursor!=='*'){const parsed=JSON.parse(cursor);if(!parsed||typeof parsed.id!=='string'||!/^news:[a-f0-9]{64}$/.test(parsed.id)||typeof parsed.published!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(parsed.published))throw Error('기사 페이지 조건을 확인해 주세요.');anchor=parsed;}
 // Keyset paging stays distinct when scheduled collection inserts newer rows.
 const anchorClause=anchor?' AND (a.published<? OR (a.published=? AND a.id>?))':'';
 const pagingArgs=anchor?[anchor.published,anchor.published,anchor.id]:[page*40];
 const rows=await db.prepare('SELECT a.body FROM news_articles a WHERE a.published>=? AND a.published<=?'+clause+anchorClause+' ORDER BY a.published DESC,a.id LIMIT 40'+(anchor?'':' OFFSET ?')).bind(...args,...pagingArgs).all<{body:string}>();
 const items=rows.results.map(r=>JSON.parse(r.body) as SearchItem),next=items.length===40?page+1:null,last=items.at(-1);
 return {items,available:count?.total||0,next,nextCursor:next!==null&&last?JSON.stringify({published:last.published,id:last.id}):undefined,query:q,provider:'corpus',fetchedAt:new Date().toISOString(),note:'매일 자동 수집해 누적한 기사입니다. 산업별 기업·기술 검색의 후보 자료이며, 검색된 산업이 기사의 확정 분류나 변화 분석을 의미하지는 않습니다. 2026년 7월 이후 과거 자료는 나눠서 보충합니다.'};
}
