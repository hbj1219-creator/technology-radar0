import {env} from "cloudflare:workers";
import {evaluateImportance} from './importance';
import {applyEditorialCorrection} from './editorial-updates';
import {refreshStoredImportance} from './importance-storage';
import {refreshStoredAssessments} from './assessment-storage';
import {applyEventAssessment} from './event-assessments';
export function database(){if(!env.DB)throw new Error("데이터 저장소에 연결할 수 없습니다.");return env.DB;}
export async function readData(user:string|null,updater=false){
 const db=database(),today=new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Seoul"}).format(new Date());
 const importanceMigration=await refreshStoredImportance(db);
 const assessmentMigration=await refreshStoredAssessments(db);
 const cutoff=(days:number)=>new Date(Date.parse(today+"T00:00:00Z")-(days-1)*86400000).toISOString().slice(0,10);
 const [rows,prefs,stats,last,followed,updates,newsStats]=await Promise.all([
  db.prepare("SELECT body FROM records ORDER BY published DESC").all<{body:string}>(),
  user?db.prepare("SELECT key,type FROM preferences WHERE user=?").bind(user).all():Promise.resolve({results:[]}),
  db.prepare("SELECT technology,COUNT(DISTINCT CASE WHEN day>=? THEN user END) AS readers1,COUNT(DISTINCT CASE WHEN day>=? THEN user END) AS readers7,COUNT(DISTINCT user) AS readers30 FROM views WHERE day>=? AND day<=? GROUP BY technology").bind(today,cutoff(7),cutoff(30),today).all(),
  db.prepare("SELECT * FROM runs ORDER BY completed DESC LIMIT 1").first(),
  updater?db.prepare("SELECT DISTINCT key FROM preferences WHERE type='follow'").all<{key:string}>():Promise.resolve({results:[]}),
  db.prepare("SELECT body FROM industry_updates ORDER BY published DESC,id ASC").all<{body:string}>(),
  db.prepare("SELECT ni.industry,COUNT(*) AS count,MAX(a.collected) AS updated FROM news_industries ni JOIN news_articles a ON a.id=ni.article_id WHERE a.published>='2026-07-01' AND a.published<=? GROUP BY ni.industry UNION ALL SELECT 'all',COUNT(*),MAX(collected) FROM news_articles WHERE published>='2026-07-01' AND published<=?").bind(today,today).all<{industry:string;count:number;updated:string|null}>()
 ]);
 const assess=(body:string)=>{const item=applyEventAssessment(applyEditorialCorrection(JSON.parse(body)));return {...item,importance:evaluateImportance(item)};};
 return {records:rows.results.map(r=>assess(r.body)),industryUpdates:updates.results.map(r=>assess(r.body)),importanceMigration,assessmentMigration,newsStats:newsStats.results,preferences:prefs.results,views:stats.results,lastRun:last,signedIn:!!user,...(updater?{followedTechnologies:followed.results.map(r=>r.key)}:{})};
}
