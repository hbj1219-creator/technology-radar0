#!/usr/bin/env python3
"""Resume authenticated article collection; credentials are stdin-only."""
import sys,json,urllib.request,urllib.error,time
if sys.stdin.isatty():
    import termios
    settings=termios.tcgetattr(sys.stdin)
    settings[3]&=~termios.ECHO
    termios.tcsetattr(sys.stdin,termios.TCSANOW,settings)
    print('Ready for collection JSON on stdin (input is hidden).',flush=True)
x=json.loads(sys.stdin.readline())
base=x['url'].rstrip('/')
if not base.startswith('https://') or not base.endswith('.chatgpt.site'):
    raise ValueError('Expected a verified Sites origin')
headers={'OAI-Sites-Authorization':'Bearer '+x['token'],'X-Radar-Updater-Token':x.get('updaterToken',x['token']),'Content-Type':'application/json'}
def call(payload=None):
    request=urllib.request.Request(base+'/api/collect',data=json.dumps(payload,ensure_ascii=False).encode() if payload else None,headers=headers)
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request,timeout=90) as response:return json.load(response)
        except urllib.error.HTTPError as e:
            if e.code in (400,401,403):raise RuntimeError('Collection authorization or input rejected: '+str(e.code)) from None
            if attempt==2:raise RuntimeError('Collection failed: '+str(e.code)) from None
        except Exception:
            if attempt==2:raise RuntimeError('Collection source unavailable') from None
        time.sleep(2)
config=call()
industries=x.get('industries') or config['industries']
mode=x.get('mode','recent')
limit=min(100,max(1,int(x.get('maxBatches',40 if mode=='recent' else 8))))
added=0; failures=[];finished=[];source_failures=0
for industry in industries:
    for batch in range(limit):
        try:r=call({'industry':industry,'mode':mode})
        except RuntimeError as e:
            failures.append({'industry':industry,'error':str(e)});break
        added+=r.get('added',0)
        source_failures+=r.get('failed',0)
        print(json.dumps(r,ensure_ascii=False),flush=True)
        if r.get('done'):
            finished.append(industry);break
        if r.get('busy') or r.get('retry'):
            failures.append({'industry':industry,'error':'Incomplete; checkpoint retained'});break
    else:
        failures.append({'industry':industry,'error':'Batch budget reached; remaining work retained'})
after=call()
print(json.dumps({'mode':mode,'added':added,'finished':finished,'failures':failures,'sourceFailures':source_failures,'partial':bool(failures or source_failures),'total':after['total'],'counts':after['counts']},ensure_ascii=False),flush=True)
if failures:sys.exit(2)
