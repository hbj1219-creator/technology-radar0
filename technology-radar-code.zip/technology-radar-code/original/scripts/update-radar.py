#!/usr/bin/env python3
"""Private Site service writer. Receives secrets on stdin only; never stores them."""
import sys,json,urllib.request,urllib.error
x=json.load(sys.stdin)
base=x['url'].rstrip('/')
if not base.startswith('https://') or not base.endswith('.chatgpt.site'):
    raise ValueError('Expected a verified Sites origin')
headers={'OAI-Sites-Authorization':'Bearer '+x['token'],'Content-Type':'application/json'}
headers['X-Radar-Updater-Token']=x.get('updaterToken',x['token'])
path='/api/update' if 'payload' in x else '/api/data'
r=urllib.request.Request(base+path,data=json.dumps(x['payload'],ensure_ascii=False).encode() if 'payload' in x else None,headers=headers)
try:
    with urllib.request.urlopen(r,timeout=50) as response:
        result=json.load(response)
        if path=='/api/data' and not x.get('full'):
            result={'records':len(result.get('records',[])),'industryUpdates':len(result.get('industryUpdates',[])),'industryUpdateIds':[r['id'] for r in result.get('industryUpdates',[])],'followedTechnologies':result.get('followedTechnologies',[]),'lastRun':result.get('lastRun'),'ids':[r['id'] for r in result.get('records',[])]}
        print(json.dumps(result,ensure_ascii=False))
except urllib.error.HTTPError as e:
    print(json.dumps({'httpStatus':e.code,'error':e.read(3000).decode()},ensure_ascii=False))
    sys.exit(1)
