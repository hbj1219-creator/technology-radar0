declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    RADAR_UPDATER_TOKEN?: string;
    BUCKET?: R2Bucket;
  }
}
