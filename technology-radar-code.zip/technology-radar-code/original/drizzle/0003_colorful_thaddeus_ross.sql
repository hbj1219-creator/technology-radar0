CREATE TABLE `news_collection_retries` (
	`scope` text NOT NULL,
	`job_index` integer NOT NULL,
	`updated` text NOT NULL,
	`attempts` integer NOT NULL,
	PRIMARY KEY(`scope`, `job_index`)
);
