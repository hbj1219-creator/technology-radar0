CREATE TABLE `preferences` (
	`user` text NOT NULL,
	`key` text NOT NULL,
	`type` text NOT NULL,
	`created` text NOT NULL,
	PRIMARY KEY(`user`, `key`, `type`)
);
--> statement-breakpoint
CREATE TABLE `records` (
	`id` text PRIMARY KEY NOT NULL,
	`url` text NOT NULL,
	`technology` text NOT NULL,
	`published` text NOT NULL,
	`body` text NOT NULL,
	`collected` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `records_url_unique` ON `records` (`url`);--> statement-breakpoint
CREATE INDEX `records_technology_published` ON `records` (`technology`,`published`);--> statement-breakpoint
CREATE TABLE `runs` (
	`id` text PRIMARY KEY NOT NULL,
	`completed` text NOT NULL,
	`status` text NOT NULL,
	`checked` integer NOT NULL,
	`added` integer NOT NULL,
	`note` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `views` (
	`user` text NOT NULL,
	`technology` text NOT NULL,
	`day` text NOT NULL,
	PRIMARY KEY(`user`, `technology`, `day`)
);
--> statement-breakpoint
CREATE INDEX `views_day` ON `views` (`day`);