CREATE TABLE `industry_updates` (
	`id` text PRIMARY KEY NOT NULL,
	`industry` text NOT NULL,
	`company` text NOT NULL,
	`published` text NOT NULL,
	`body` text NOT NULL,
	`collected` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `industry_updates_industry_date` ON `industry_updates` (`industry`,`published`);