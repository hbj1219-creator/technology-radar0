CREATE TABLE `news_articles` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`source` text NOT NULL,
	`published` text NOT NULL,
	`body` text NOT NULL,
	`collected` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `news_articles_date` ON `news_articles` (`published`);--> statement-breakpoint
CREATE TABLE `news_collection_state` (
	`scope` text PRIMARY KEY NOT NULL,
	`industry` text NOT NULL,
	`mode` text NOT NULL,
	`position` integer NOT NULL,
	`total` integer NOT NULL,
	`updated` text NOT NULL,
	`lock_until` integer NOT NULL,
	`failures` integer NOT NULL,
	`note` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `news_industries` (
	`article_id` text NOT NULL,
	`industry` text NOT NULL,
	PRIMARY KEY(`article_id`, `industry`)
);
--> statement-breakpoint
CREATE INDEX `news_industries_industry` ON `news_industries` (`industry`);